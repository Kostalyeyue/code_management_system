<template>
  <div>
    <h1>{{msg}}</h1>
  </div>
</template>

<script>
  export default {
    name: "micro",
    data() {
      return {
        msg: '这是学位课'
      }
    }
  }
</script>

<style scoped>

</style>
