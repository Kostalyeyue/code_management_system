<template>
  <div>
    <h1>{{msg}}</h1>
  </div>
</template>

<script>
  export default {
    name: "news",
    data() {
      return {
        msg: '这是新闻'
      }
    }
  }
</script>

<style scoped>

</style>
