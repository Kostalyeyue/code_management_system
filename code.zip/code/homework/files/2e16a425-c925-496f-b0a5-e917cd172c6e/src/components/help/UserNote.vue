<template>
    <div>
        <h2>{{msg}}</h2>
    </div>
</template>

<script>
    export default {
        name: "user-note",
        data() {
            return {
                'msg': '用户手册'
            }
        }
    }
</script>

<style scoped>

</style>